//
//  CommentView.swift
//  Touchdown
//
//  Created by Md Abir Hossain on 13-05-2023.
//

import SwiftUI

struct CommentView: View {
    // MARK: - PROPERTIES
    
    
    // MARK: - BODY
    
    var body: some View {
            Text("Copyright")
    }
}

// MARK: - PREVIEW

struct CommentView_Previews: PreviewProvider {
    static var previews: some View {
        CommentView()
            .previewLayout(.sizeThatFits)
            .background(colorBackground)
    }
}
